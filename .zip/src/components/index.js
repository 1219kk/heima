import Vue from 'vue'
import CollectArticle from './CollectArticle.vue'
import LikeArticle from './LikeArticle.vue'
Vue.component(CollectArticle.name, CollectArticle)
Vue.component(LikeArticle.name, LikeArticle)

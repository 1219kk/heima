<template>
  <van-loading v-if="isLoading" size=".53333rem" />
  <van-icon
    v-else
    color="#777"
    :name="like_count ? 'good-job' : 'good-job-o'"
    @click="onClick"
  />
</template>

<script>
import { addLike, delLike } from '@/api/article'
export default {
  name: 'LikeArticle',
  props: {
    like_count: {
      type: [Number, String],
      required: true
    }
  },
  created () { },
  data () {
    return {
      isLoading: false
    }
  },
  methods: {
    async onClick () {
      this.isLoading = true
      if (this.like_count) {
        try {
          await delLike(this.target)
          this.$emit('update:like_count', !this.like_count)
        } catch (err) {
          console.log(err)
        }
      } else {
        try {
          await addLike(this.target)
          this.$emit('update:like_count', !this.like_count)
        } catch (err) {
          console.log(err)
        }
        this.isLoading = false
      }
    }
  }
}
</script>

<style scoped lang='less'>
</style>
